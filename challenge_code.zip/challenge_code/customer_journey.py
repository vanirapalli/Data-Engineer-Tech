from sqlclient import SQLiteDatabase
from typing import List, Optional, Dict, Tuple
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
)
logger = logging.getLogger('Customer_Journey')  # Use the name of the current module

class CustomerJourneyWorker(SQLiteDatabase):
    def __init__(self, db_file: str):
        """
        Initialize a CustomerJourneyWorker instance with a database file.

        Args:
            db_file (str): The path to the SQLite database file.
        """
        super().__init__(db_file)

    def create_tables(self):
        """
        Create tables in the database if they don't exist.

        This method creates the 'attribution_customer_journey' table if it doesn't already exist.

        Returns:
            None
        """
        create_query = """
        CREATE TABLE attribution_customer_journey (
            conv_id TEXT,
            session_id TEXT,
            ihc REAL,
            UNIQUE (conv_id, session_id)
        );
        """

        self.validate_table_else_create('attribution_customer_journey', create_query)

    def fetch_customer_journey_data(self, start_date: Optional[str] = None, end_date: Optional[str] = None) -> List[Dict[str, str]]:
        """
        Fetch data from the database using a select query.

        Args:
            start_date (str, optional): Start date of the time range. Defaults to None.
            end_date (str, optional): End date of the time range. Defaults to None.

        Returns:
            List[Dict[str, str]]: A list of dictionaries representing the query results.
        """
        select_query = """
        SELECT
        c.conv_id as conversion_id,
        s.session_id as session_id,
        (s.event_date || ' ' || s.event_time) AS timestamp,
        s.channel_name as channel_label,
        s.holder_engagement as holder_engagement,
        s.closer_engagement as closer_engagement,
        s.impression_interaction as impression_interaction
        FROM
        conversions c
        INNER JOIN
        session_sources s ON c.user_id = s.user_id
        WHERE
        (s.event_date < c.conv_date OR (s.event_date=c.conv_date AND s.event_time <= c.conv_time))
        """
        
        if start_date:
            select_query += f" AND s.event_date >= '{start_date}'"
        if end_date:
            select_query += f" AND s.event_date <= '{end_date}'"

        select_query += "ORDER BY c.conv_id, s.event_date, s.event_time"

        try:
            return self.execute_select_query(select_query)
        except Exception as e:
            logger.error(f"Error fetching customer journey data: {e}", exc_info=True)  # Use logger for error messages
            return []

    def transform_columns(self, data: List[Dict[str, str]]) -> List[Dict[str, str]]:
        """
        Transform the fetched data as needed.

        Args:
            data (List[Dict[str, str]]): The data to transform.

        Returns:
            List[Dict[str, str]]: The transformed data.
        """
        # Example transformation: Convert fetched data to a list of dictionaries
        transform = []
        for i, result in enumerate(data):
            if i == len(data)-1:
                result["conversion"] = 1
            else:
                if data[i+1]["conversion_id"] != result["conversion_id"]:
                    result["conversion"] = 1
                else:
                    result["conversion"] = 0
            transform.append(result)

        return transform

    def transform_to_row(self, item: Dict[str, str]) -> Tuple[str, str, float]:
        """
        Transform a dictionary item into a row for database insertion.

        Args:
            item (Dict[str, str]): The dictionary item to transform.

        Returns:
            Tuple[str, str, float]: The transformed row data.
        """
        row = (f'{item["conversion_id"]}', f'{item["session_id"]}', item["ihc"])
        return row

    def transform_data(self, batch: List[Dict[str, str]]) -> List[Tuple[str, str, float]]:
        """
        Transform a batch of data.

        Args:
            batch (List[Dict[str, str]]): The batch of data to transform.

        Returns:
            List[Tuple[str, str, float]]: The transformed data.
        """
        return [self.transform_to_row(item) for item in batch]

    def insert_rows(self, rows: List[Tuple[str, str, float]]) -> int:
        """
        Insert rows into the 'attribution_customer_journey' table.

        Args:
            rows (List[Tuple[str, str, float]]): The rows to insert.

        Returns:
            int: The number of rows inserted.
        """
        insert_sql = f"INSERT OR IGNORE INTO attribution_customer_journey (conv_id, session_id, ihc) VALUES (?,?,?)"
        try:
            return self.execute_many(insert_sql, rows)
        except Exception as e:
            logger.error(f"Error inserting rows: {e}", exc_info=True)  # Use logger for error messages
            return 0
