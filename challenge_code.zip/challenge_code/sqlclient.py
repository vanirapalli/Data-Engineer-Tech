import sqlite3
from typing import List, Dict, Optional
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
)
logger = logging.getLogger('SQLClient')  # Use the name of the current module

class SQLiteDatabase:
    def __init__(self, db_file: str):
        """
        Initialize the SQLite database by opening a connection to the specified file.

        Args:
            db_file (str): The path to the SQLite database file.
        """
        try:
            self.conn = sqlite3.connect(db_file)
            self.conn.row_factory = sqlite3.Row
            self.cursor = self.conn.cursor()
        except sqlite3.Error as e:
            logger.error(f"Error connecting to the database: {e}", exc_info=True)
            raise e  # Raise the exception to propagate the error

    def validate_table_else_create(self, table_name: str, create_table: str) -> None:
        """
        Validate if a table exists; if not, create it.

        Args:
            table_name (str): The name of the table to check or create.
            create_table (str): The CREATE TABLE query to execute.

        Returns:
            None
        """
        table_exists = self.table_exists(table_name)

        if not table_exists:
            try:
                # Execute the CREATE TABLE query
                if self.execute_create_table_query(create_table):
                    logger.info(f"Table {table_name} created successfully")
                else:
                    logger.error(f"Table {table_name} creation failed")
            except sqlite3.Error as e:
                logger.error(f"Error creating table '{table_name}': {e}", exc_info=True)
        else:
            logger.info(f"Table {table_name} already exists, skipping creation")

    def table_exists(self, table_name: str) -> bool:
        """
        Check if a table with the specified name exists in the database.

        Args:
            table_name (str): The name of the table to check.

        Returns:
            bool: True if the table exists; False otherwise.
        """
        try:
            # Query the sqlite_master table to check for the existence of the table
            self.cursor.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name=?;", (table_name,))
            result = self.cursor.fetchone()
            return result is not None
        except sqlite3.Error as e:
            logger.error(f"Error checking if table '{table_name}' exists: {e}", exc_info=True)
            return False

    def execute_create_table_query(self, create_table_sql: str) -> bool:
        """
        Execute a CREATE TABLE query to create a new table in the database.

        Args:
            create_table_sql (str): The CREATE TABLE query to execute.

        Returns:
            bool: True if the table was created successfully; False otherwise.
        """
        try:
            self.cursor.execute(create_table_sql)
            self.conn.commit()
            return True
        except sqlite3.Error as e:
            logger.error("Error executing CREATE TABLE query: {e}", exc_info=True)
            self.conn.rollback()
            return False

    def execute_select_query(self, query: str) -> List[Dict[str, str]]:
        """
        Execute a SELECT query on the initialized database and return the results.

        Args:
            query (str): The SELECT query to execute.

        Returns:
            List[Dict[str, str]]: A list of dictionaries representing the query results.
        """
        try:
            self.cursor.execute(query)
            results = self.cursor.fetchall()
            return [dict(row) for row in results]
        except sqlite3.Error as e:
            logger.error(f"Error executing SELECT query: {e}", exc_info=True)
            return []

    def execute_insert_update_query(self, query: str) -> bool:
        """
        Execute an INSERT or UPDATE query on the database, commit the changes, and return success or failure.

        Args:
            query (str): The INSERT or UPDATE query to execute.

        Returns:
            bool: True if the query was executed successfully; False otherwise.
        """
        try:
            self.cursor.execute(query)
            self.conn.commit()
            return True
        except sqlite3.Error as e:
            logger.error(f"Error executing INSERT/UPDATE query: {e}", exc_info=True)
            self.conn.rollback()
            return False
    
    def execute_many(self, query: str, data_to_insert: List[tuple]) -> None:
        """
        Execute an INSERT query for multiple rows and commit the changes to the database.

        Args:
            query (str): The INSERT query to execute.
            data_to_insert (List[tuple]): List of tuples representing rows to insert.

        Returns:
            None
        """
        try:
            self.cursor.executemany(query, data_to_insert)
            self.conn.commit()
        except sqlite3.Error as e:
            logger.error(f"Error executing INSERT query for multiple rows: {e}", exc_info=True)
            self.conn.rollback()

    def db_close(self):
        """
        Close the database connection.
        """
        try:
            self.conn.close()
        except sqlite3.Error as e:
            logger.error(f"Error closing the database connection: {e}", exc_info=True)
