import requests
import logging
from typing import List, Dict, Union

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
)
logger = logging.getLogger('IHCAPIClient')

class ApiIterator:
    def __init__(self, data: List[Union[int, str]], batch: int):
        """
        Initialize an iterator for batching data.

        Args:
            data (List[Union[int, str]]): The input data to be iterated over.
            batch (int): The batch size for each iteration.
        """
        self.data = data
        self.data_len = len(data)
        self.batch = batch
        self.curr_count = 0

    def __iter__(self) -> 'ApiIterator':
        """
        Initialize the iterator.

        Returns:
            ApiIterator: The iterator object.
        """
        return self

    def __next__(self) -> List[Union[int, str]]:
        """
        Get the next batch of data.

        Returns:
            List[Union[int, str]]: The next batch of data.
        
        Raises:
            StopIteration: Raised when there is no more data to iterate over.
        """
        if self.curr_count == self.data_len:
            raise StopIteration
        if self.curr_count + self.batch < self.data_len:
            result = self.data[self.curr_count:self.curr_count + self.batch]
            self.curr_count += self.batch
        else:
            result = self.data[self.curr_count:]
            self.curr_count = self.data_len

        logger.info(f"Processed {self.curr_count}/{self.data_len} items")  # Use logger for informational messages

        return result

class IHCAPIClient:
    def __init__(self, api_key: str):
        """
        Initialize an IHCAPIClient instance with an API key.

        Args:
            api_key (str): The API key to use for authentication.
        """
        self.headers = {
            'Content-Type': 'application/json',
            "x-api-key": api_key
        }

    def post_data(self, url: str, customer_journeys: List[Dict[str, Union[int, str]]]) -> Union[Dict[str, Union[int, str]], None]:
        """
        Make a POST request to the API.

        Args:
            url (str): The API endpoint to send the POST request to.
            customer_journeys (List[Dict[str, Union[int, str]]]): List of sessions making up customer journeys.

        Returns:
            Union[Dict[str, Union[int, str]], None]: The JSON response from the API, or None in case of an error.
        """
        data = {
            "customer_journeys": customer_journeys
        }

        try:
            response = requests.post(url, json=data, headers=self.headers)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error making POST request: {e}", exc_info=True)  # Use logger for error messages
            return None
