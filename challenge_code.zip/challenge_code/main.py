import logging
import argparse
import sys
from datetime import datetime

from customer_journey import CustomerJourneyWorker
from ihcapiclient import IHCAPIClient, ApiIterator
from channel_report import ChannelReportWorker
from typing import Optional

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
)
logger = logging.getLogger("htcapi")

def validate_date(date_str):
    try:
        return datetime.strptime(date_str, '%Y-%m-%d')
    except ValueError:
        raise argparse.ArgumentTypeError("Invalid date format. Use YYYY-MM-DD.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Data Engineering Challenge")

    parser.add_argument("--api_key", type=str, help="API key to connect to ihc")
    parser.add_argument("--start_date", type=validate_date, help="Start date (YYYY-MM-DD) of the time range")
    parser.add_argument("--end_date", type=validate_date, help="End date (YYYY-MM-DD) of the time range")

    args = parser.parse_args()

    cj_worker = CustomerJourneyWorker("challenge.db")

    try:
        cj_worker.create_tables()
    except Exception as e:
        logger.error(f"Error creating tables: {e}", exc_info=True)
        sys.exit(1)

    api_key = args.api_key

    start_date = args.start_date
    end_date = args.end_date

    if start_date and end_date:
        logger.info(f"Fetching customer journey data for the time range: {start_date} to {end_date}")
    else:
        logger.info("Fetching all customer journey data")

    try:
        cj_data = cj_worker.fetch_customer_journey_data(start_date, end_date)
    except Exception as e:
        logger.error(f"Error fetching customer journey data: {e}", exc_info=True)
        cj_worker.db_close()
        sys.exit(1)

    logger.info("Transforming customer journey data")
    transform = cj_worker.transform_columns(cj_data)

    api_client = IHCAPIClient(api_key)
    api_url = "https://api.ihc-attribution.com/v1/compute_ihc?conv_type_id=data_engineering_challenge"
    data_iter = ApiIterator(transform, 100)
    customer_ihc = []

    logger.info("Starting data iteration")
    for data in data_iter:
        try:
            response = api_client.post_data(api_url, data)
            if response["statusCode"] == 200:
                insert_rows = cj_worker.transform_data(response["value"])
                logger.info("Inserting rows into attribution_customer_journey table")
                cj_worker.insert_rows(insert_rows)
            else:
                logger.error("Something went wrong with the API")
        except Exception as e:
            logger.error(f"Error processing data: {e}", exc_info=True)

    logger.info("Completed syncing customer journey")

    cj_worker.db_close()

    channel_worker = ChannelReportWorker("challenge.db")

    try:
        channel_worker.create_table()
    except Exception as e:
        logger.error(f"Error creating table in channel_report: {e}", exc_info=True)
        sys.exit(1)

    logger.info("Started channel_reporting sync")

    try:
        channel_worker.synch_channel_report(start_date, end_date)
    except Exception as e:
        logger.error(f"Error syncing channel report: {e}", exc_info=True)
        channel_worker.db_close()
        sys.exit(1)

    logger.info("Successfully inserted data into channel_reporting table")

    try:
        channel_worker.create_channel_report(start_date, end_date)
    except Exception as e:
        logger.error(f"Error creating channel report: {e}", exc_info=True)
        sys.exit(1)

    channel_worker.db_close()
