import logging
from sqlclient import SQLiteDatabase
import csv
import datetime
from typing import Optional

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
)
logger = logging.getLogger('Channel_Report')  # Use the name of the current module

class ChannelReportWorker(SQLiteDatabase):
    def __init__(self, db_file: str):
        """
        Initialize a ChannelReportWorker instance with a database file.

        Args:
            db_file (str): The path to the SQLite database file.
        """
        super().__init__(db_file)

    def create_table(self) -> None:
        """
        Create the 'channel_reporting' table in the database if it doesn't exist.

        Returns:
            None
        """
        create_query = """
        CREATE TABLE channel_reporting (
            channel_name TEXT,
            date DATE,
            cost REAL,
            ihc REAL,
            ihc_revenue REAL
        );
        """

        self.validate_table_else_create('channel_reporting', create_query)

    def synch_channel_report(self, start_date: Optional[str] = None, end_date: Optional[str] = None) -> None:
        """
        Synchronize channel reporting data from various sources into the 'channel_reporting' table.

        Args:
            start_date (str, optional): Start date of the time range. Defaults to None.
            end_date (str, optional): End date of the time range. Defaults to None.

        Returns:
            None
        """
        try:
            channel_query = """
            SELECT 
            s.channel_name,
            s.event_date,
            SUM(sc.cost) AS cost,
            SUM(acj.ihc) AS ihc,
            SUM(acj.ihc * c.revenue) AS ihc_revenue
            FROM session_sources s, attribution_customer_journey acj, session_costs sc, conversions c 
            WHERE s.session_id=acj.session_id 
            AND sc.session_id=acj.session_id 
            AND c.conv_id=acj.conv_id
            """

            if start_date:
                channel_query += f" AND s.event_date >= '{start_date}'"
            if end_date:
                channel_query += f" AND s.event_date <= '{end_date}'"

            channel_query += "GROUP BY s.channel_name, s.event_date"

            channel_data = self.execute_select_query(channel_query)
            logger.info(f"Total {len(channel_data)} records found")
            for data in channel_data:
                cost = data["cost"] if data["cost"] else 0
                select_query = f'SELECT * FROM channel_reporting WHERE channel_name="{data["channel_name"]}" AND date="{data["event_date"]}"'
                row_data = self.execute_select_query(select_query)
                if len(row_data) > 0:
                    update_query = f'UPDATE channel_reporting SET ihc={data["ihc"]}, cost={cost}, ihc_revenue={data["ihc_revenue"]} WHERE channel_name="{data["channel_name"]}" AND date="{data["event_date"]}"'
                    self.execute_insert_update_query(update_query)
                else:
                    insert_query = f'INSERT INTO channel_reporting (channel_name, date, cost, ihc, ihc_revenue) VALUES ("{data["channel_name"]}", "{data["event_date"]}", {cost}, {data["ihc"]}, {data["ihc_revenue"]})'
                    self.execute_insert_update_query(insert_query)

        except Exception as e:
            logger.error(f"Error in synch_channel_report: {e}", exc_info=True)

    def create_channel_report(self, start_date: Optional[str] = None, end_date: Optional[str] = None) -> None:
        """
        Create a channel report and export it to a CSV file.

        Args:
            start_date (str, optional): Start date of the time range. Defaults to None.
            end_date (str, optional): End date of the time range. Defaults to None.

        Returns:
            None
        """
        try:
            channel_report_query = """
            SELECT 
            cr.channel_name,
            cr.date,
            cr.cost,
            cr.ihc,
            cr.ihc_revenue,
            cr.cost / COUNT(acj.session_id) AS cpo,
            cr.ihc_revenue / cr.cost AS roas
            FROM channel_reporting cr
            INNER JOIN session_sources ss ON cr.date = ss.event_date
            INNER JOIN attribution_customer_journey acj ON ss.session_id = acj.session_id
            WHERE 1=1 
            """

            if start_date:
                channel_report_query += f" AND cr.date >= '{start_date}'"
            if end_date:
                channel_report_query += f" AND cr.date <= '{end_date}'"

            channel_report_query += "GROUP BY cr.channel_name, cr.date"
            
            results = self.execute_select_query(channel_report_query)

            date_time = datetime.datetime.now().strftime("%Y-%m-%d %H-%M-%S")
            csv_filename = f'channel_reports/channel_reporting_{date_time}.csv'
            fieldnames = ['channel_name', 'date', 'cost', 'ihc', 'ihc_revenue', 'cpo', 'roas']

            with open(csv_filename, mode='w', newline='') as csv_file:
                writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(results)

            logger.info(f'Data saved to {csv_filename}')
        
        except Exception as e:
            logger.error(f"Error in create_channel_report: {e}", exc_info=True)

if __name__ == "__main__":
    channel_worker = ChannelReportWorker("challenge.db")
    channel_worker.create_table()
    logger.info("Started channel_reporting sync")
    channel_worker.synch_channel_report()
    logger.info("Successfully inserted data into channel_reporting table")
    channel_worker.create_channel_report()
    logger.info("Loaded data into CSV")
    channel_worker.db_close()
